SAZZADUL IHT ACADEMY — TELEGRAM EXAM BOT
=========================================

এই ZIP-এ একটি প্রাথমিক পরীক্ষামূলক বট আছে। questions.json-এ ১০টি নমুনা প্রশ্ন আছে।
১০০ প্রশ্ন করতে একই ফরম্যাটে আরও ৯০টি প্রশ্ন যোগ করো। answer হলো options-এর 0-based index:
প্রথম অপশন=0, দ্বিতীয়=1, তৃতীয়=2, চতুর্থ=3।

গুরুত্বপূর্ণ সীমাবদ্ধতা:
- Render-এর Free web service নিষ্ক্রিয় থাকলে ঘুমিয়ে যেতে পারে।
- এই starter version SQLite ব্যবহার করে; Render free filesystem স্থায়ী নয়, তাই restart/redeploy হলে ফলাফল হারাতে পারে।
- নিয়মিত/গুরুত্বপূর্ণ পরীক্ষার আগে persistent database যুক্ত করা উচিত।
- ১০০ প্রশ্নের চূড়ান্ত প্রশ্নব্যাংক নিজে যাচাই করে দাও; এখানে কেবল ১০টি demo প্রশ্ন আছে।
- BOT_TOKEN কখনো কাউকে পাঠাবে না বা public repository-তে রাখবে না।

ধাপ ১: Telegram bot তৈরি
1. Telegram-এ @BotFather খোলো।
2. /newbot পাঠাও, নাম ও username সেট করো।
3. BotFather-এর token কপি করে গোপন রাখো।

ধাপ ২: Admin ID
1. Telegram-এ @userinfobot খুঁজে নিজের numeric user ID দেখো।
2. সেটি Render-এর ADMIN_ID হিসেবে ব্যবহার করো।

ধাপ ৩: Channel
1. নিজের Telegram channel তৈরি করো।
2. bot-কে channel-এর Admin করো (post messages permission সহ)।
3. CHANNEL_ID-তে @your_channel_username দাও (public channel হলে), অথবা numeric channel ID।

ধাপ ৪: GitHub-এ ফাইল আপলোড
1. GitHub-এ sign in করে New repository তৈরি করো।
2. ZIP extract করে সব ফাইল repository-তে upload করো।
3. Repository public করলে token বা secret কখনো ফাইলে রেখো না; এই ZIP-এ token নেই।

ধাপ ৫: Render deploy
1. render.com-এ sign in করো এবং New > Web Service বেছে নাও।
2. GitHub repository connect করো।
3. Runtime Python, Build Command: pip install -r requirements.txt
4. Start Command: python bot.py
5. Free plan বেছে নাও।
6. Environment Variables যোগ করো:
   BOT_TOKEN = BotFather token
   ADMIN_ID = তোমার numeric Telegram user ID
   CHANNEL_ID = @তোমার_public_channel_username (চ্যানেলে পোস্ট না চাইলে ফাঁকা)
   WEBHOOK_URL = Render deploy শেষে পাওয়া https://....onrender.com URL
7. প্রথম deploy-এর সময় WEBHOOK_URL না থাকলে deploy শেষে সেটি যোগ করে redeploy করো।

ধাপ ৬: পরীক্ষা
1. Render deploy সফল হলে service URL খোলো; JSON status দেখা উচিত।
2. Telegram-এ bot খুঁজে /start পাঠাও।
3. 📝 পরীক্ষা শুরু চাপো।
4. Admin-এ /admin এবং /stats পাঠাও।
5. চ্যানেলে নোটিশ দিতে /post আগামীকাল পরীক্ষা হবে লিখো।

কমান্ড:
 /start  — মেনু
 /exam   — পরীক্ষা শুরু
 /result — সর্বশেষ ফলাফল
 /admin  — অ্যাডমিন কমান্ড (শুধু ADMIN_ID)
 /stats  — শিক্ষার্থী ও পরীক্ষার হিসাব
 /post নোটিশের লেখা — চ্যানেলে পোস্ট (শুধু ADMIN_ID)

নোট: এটি একটি starter prototype; public exam চালুর আগে persistent database, exam timer, question upload/admin panel,
duplicate attempts rules এবং result privacy যাচাই করে উন্নত করা দরকার।
