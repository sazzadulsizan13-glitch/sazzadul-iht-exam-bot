import os, json, sqlite3, logging, requests
from flask import Flask, request, jsonify

logging.basicConfig(level=logging.INFO)
app = Flask(__name__)

TOKEN = os.environ.get("BOT_TOKEN", "").strip()
ADMIN_ID = os.environ.get("ADMIN_ID", "").strip()
CHANNEL_ID = os.environ.get("CHANNEL_ID", "").strip()
WEBHOOK_URL = os.environ.get("WEBHOOK_URL", "").strip().rstrip("/")
DB_PATH = os.environ.get("DB_PATH", "bot.db")
API = f"https://api.telegram.org/bot{TOKEN}"

init_placeholder = None
with open("questions.json", "r", encoding="utf-8") as f:
    QUESTIONS = json.load(f)

def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS users(
            user_id INTEGER PRIMARY KEY, name TEXT, username TEXT, joined_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
        con.execute("""CREATE TABLE IF NOT EXISTS attempts(
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, score INTEGER,
            total INTEGER, finished_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
        con.execute("""CREATE TABLE IF NOT EXISTS answers(
            user_id INTEGER, q_index INTEGER, choice INTEGER,
            PRIMARY KEY(user_id, q_index))""")
        con.execute("""CREATE TABLE IF NOT EXISTS active(
            user_id INTEGER PRIMARY KEY, q_index INTEGER DEFAULT 0, started_at TEXT DEFAULT CURRENT_TIMESTAMP)""")

def tg(method, payload=None):
    if not TOKEN:
        logging.error("BOT_TOKEN is missing")
        return {}
    try:
        r = requests.post(f"{API}/{method}", json=payload or {}, timeout=20)
        r.raise_for_status()
        data = r.json()
        if not data.get("ok"):
            logging.warning("Telegram API response: %s", data)
        return data
    except Exception:
        logging.exception("Telegram API call failed: %s", method)
        return {}

def send(chat_id, text, keyboard=None):
    payload = {"chat_id": chat_id, "text": text}
    if keyboard:
        payload["reply_markup"] = {"inline_keyboard": keyboard}
    return tg("sendMessage", payload)

def main_keyboard():
    return [[{"text":"📝 পরীক্ষা শুরু","callback_data":"exam"}],
            [{"text":"🏆 আমার ফলাফল","callback_data":"result"},
             {"text":"ℹ️ সাহায্য","callback_data":"help"}]]

def is_admin(uid):
    return ADMIN_ID.isdigit() and str(uid) == ADMIN_ID

def start_exam(uid, chat_id):
    if not QUESTIONS:
        return send(chat_id, "এখনো প্রশ্ন যোগ করা হয়নি।")
    with db() as con:
        con.execute("DELETE FROM answers WHERE user_id=?", (uid,))
        con.execute("INSERT OR REPLACE INTO active(user_id,q_index) VALUES(?,0)", (uid,))
    send_question(uid, chat_id, 0)

def send_question(uid, chat_id, idx):
    if idx >= len(QUESTIONS):
        finish_exam(uid, chat_id)
        return
    q = QUESTIONS[idx]
    keyboard = []
    for i, opt in enumerate(q["options"]):
        keyboard.append([{"text": f"{'কখগঘ'[i] if i < 4 else i+1}. {opt}", "callback_data": f"ans:{idx}:{i}"}])
    send(chat_id, f"📝 প্রশ্ন {idx+1}/{len(QUESTIONS)}\n\n{q['question']}", keyboard)

def finish_exam(uid, chat_id):
    with db() as con:
        row = con.execute("SELECT COUNT(*) n FROM answers WHERE user_id=? AND q_index IN (SELECT value FROM json_each(?))",
                          (uid, json.dumps(list(range(len(QUESTIONS)))))).fetchone()
        answers = con.execute("SELECT q_index,choice FROM answers WHERE user_id=?", (uid,)).fetchall()
        chosen = {int(a["q_index"]): int(a["choice"]) for a in answers}
        score = sum(1 for i,q in enumerate(QUESTIONS) if chosen.get(i) == int(q["answer"]))
        con.execute("INSERT INTO attempts(user_id,score,total) VALUES(?,?,?)", (uid, score, len(QUESTIONS)))
        con.execute("DELETE FROM active WHERE user_id=?", (uid,))
    pct = round(score * 100 / len(QUESTIONS)) if QUESTIONS else 0
    send(chat_id, f"✅ পরীক্ষা শেষ!\n\nনম্বর: {score}/{len(QUESTIONS)}\nশতকরা: {pct}%\n\nআরও পরীক্ষার জন্য নিচের মেনু ব্যবহার করো।", main_keyboard())

def handle_message(msg):
    chat = msg.get("chat", {})
    uid = msg.get("from", {}).get("id")
    chat_id = chat.get("id")
    text = (msg.get("text") or "").strip()
    if uid is None or chat_id is None:
        return
    with db() as con:
        con.execute("INSERT OR REPLACE INTO users(user_id,name,username) VALUES(?,?,?)",
                    (uid, msg.get("from",{}).get("first_name",""), msg.get("from",{}).get("username","")))
    if text.startswith("/start"):
        send(chat_id, "স্বাগতম! 🎓\nSazzadul IHT Academy\n\nএখান থেকে MCQ পরীক্ষা দাও এবং নিজের ফলাফল দেখো।", main_keyboard())
    elif text.startswith("/exam"):
        start_exam(uid, chat_id)
    elif text.startswith("/result"):
        with db() as con:
            row = con.execute("SELECT score,total,finished_at FROM attempts WHERE user_id=? ORDER BY id DESC LIMIT 1", (uid,)).fetchone()
        if row:
            send(chat_id, f"🏆 সর্বশেষ ফলাফল: {row['score']}/{row['total']}\nসময়: {row['finished_at']}")
        else:
            send(chat_id, "এখনো কোনো পরীক্ষা শেষ করোনি। /exam লিখে শুরু করো।")
    elif text.startswith("/help"):
        send(chat_id, "কমান্ড:\n/start — মেনু\n/exam — পরীক্ষা শুরু\n/result — সর্বশেষ ফলাফল\n/help — সাহায্য", main_keyboard())
    elif text.startswith("/stats") and is_admin(uid):
        with db() as con:
            users = con.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]
            attempts = con.execute("SELECT COUNT(*) n FROM attempts").fetchone()["n"]
        send(chat_id, f"📊 Admin Stats\nশিক্ষার্থী: {users}\nসম্পন্ন পরীক্ষা: {attempts}")
    elif text.startswith("/post ") and is_admin(uid):
        if not CHANNEL_ID:
            send(chat_id, "CHANNEL_ID সেট করা হয়নি।")
        else:
            post_text = text[6:].strip()
            result = tg("sendMessage", {"chat_id": CHANNEL_ID, "text": post_text})
            send(chat_id, "চ্যানেলে পোস্ট পাঠানো হয়েছে।" if result.get("ok") else "পোস্ট ব্যর্থ হয়েছে। বটকে চ্যানেলে Admin করেছ কি না দেখো।")
    elif text.startswith("/admin") and is_admin(uid):
        send(chat_id, "অ্যাডমিন কমান্ড:\n/stats — ব্যবহারকারী ও পরীক্ষার হিসাব\n/post তোমার নোটিশ — চ্যানেলে নোটিশ")
    else:
        send(chat_id, "মেনু থেকে একটি অপশন বেছে নাও।", main_keyboard())

def handle_callback(cb):
    uid = cb.get("from", {}).get("id")
    chat_id = cb.get("message", {}).get("chat", {}).get("id")
    data = cb.get("data", "")
    tg("answerCallbackQuery", {"callback_query_id": cb.get("id")})
    if not uid or not chat_id:
        return
    if data == "exam":
        start_exam(uid, chat_id)
    elif data == "result":
        with db() as con:
            row = con.execute("SELECT score,total,finished_at FROM attempts WHERE user_id=? ORDER BY id DESC LIMIT 1", (uid,)).fetchone()
        send(chat_id, f"🏆 সর্বশেষ ফলাফল: {row['score']}/{row['total']}\nসময়: {row['finished_at']}" if row else "এখনো কোনো পরীক্ষা শেষ করোনি।", main_keyboard())
    elif data == "help":
        send(chat_id, "পরীক্ষা শুরু করে প্রতিটি প্রশ্নের একটি উত্তর বেছে নাও। সব প্রশ্নের পর ফলাফল দেখাবে।", main_keyboard())
    elif data.startswith("ans:"):
        try:
            _, qidx, choice = data.split(":")
            qidx, choice = int(qidx), int(choice)
        except ValueError:
            return
        with db() as con:
            active = con.execute("SELECT q_index FROM active WHERE user_id=?", (uid,)).fetchone()
            if not active or int(active["q_index"]) != qidx:
                send(chat_id, "এই প্রশ্নটি আর সক্রিয় নেই। /exam লিখে নতুন পরীক্ষা শুরু করো.")
                return
            con.execute("INSERT OR REPLACE INTO answers(user_id,q_index,choice) VALUES(?,?,?)", (uid,qidx,choice))
            con.execute("UPDATE active SET q_index=? WHERE user_id=?", (qidx+1,uid))
        send_question(uid, chat_id, qidx+1)

@app.get("/")
def home():
    return jsonify({"service":"Sazzadul IHT Academy Telegram Exam Bot","status":"running"})

@app.get("/health")
def health():
    return "ok", 200

@app.post("/telegram/webhook")
def webhook():
    update = request.get_json(silent=True) or {}
    if "message" in update:
        handle_message(update["message"])
    elif "callback_query" in update:
        handle_callback(update["callback_query"])
    return "ok", 200

init_db()

if __name__ == "__main__":
    if TOKEN and WEBHOOK_URL:
        tg("setWebhook", {"url": f"{WEBHOOK_URL}/telegram/webhook"})
    from threading import Thread
    # Initialize database before Flask serves requests.
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "10000")))
